-- phpMyAdmin SQL Dump
-- version 4.6.6deb4
-- https://www.phpmyadmin.net/
--
-- Client :  localhost
-- Généré le :  Ven 15 Février 2019 à 10:32
-- Version du serveur :  10.1.37-MariaDB-0+deb9u1
-- Version de PHP :  7.0.33-0+deb9u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `ecf_api`
--

--
-- Contenu de la table `migration_versions`
--

INSERT INTO `migration_versions` (`version`, `executed_at`) VALUES
('20190214111718', '2019-02-14 11:17:39');

--
-- Contenu de la table `resource`
--

INSERT INTO `resource` (`id`, `soft`, `alcohol`, `food`) VALUES
(1, 'Coca-Cola', 'Vodka', NULL),
(2, NULL, NULL, 'Cacahuètes, olives vertes'),
(3, 'eau', NULL, NULL),
(4, 'Pulco', NULL, 'Hamster');

--
-- Contenu de la table `resource_student`
--

INSERT INTO `resource_student` (`resource_id`, `student_id`) VALUES
(1, 3),
(2, 4),
(3, 1),
(4, 2);

--
-- Contenu de la table `student`
--

INSERT INTO `student` (`id`, `firstname`, `lastname`, `response`) VALUES
(1, 'Sullivan', 'Delaby', 1),
(2, 'Patrick', 'Bruel', 0),
(3, 'Joe', 'Bee', 1),
(4, 'Joe', 'Bas', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
